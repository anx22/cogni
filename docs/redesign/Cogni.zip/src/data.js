// COGNI — Demo-Daten für Prototyp.
// (vereinfacht aus cogni/src/data/demoProject.ts + demoProjects.ts)

window.COGNI_DATA = {
  // Projektliste — Linear-style sidebar
  projects: [
    { id: "p1", name: "Aurora Rebrand",          initial: "AR",  signals: ["review","action"], openCount: 2, last: "vor 2 h"  },
    { id: "p2", name: "Hafen Nord Erweiterung",  initial: "HN",  signals: ["conflict","action"], openCount: 5, last: "vor 25 min", live: true },
    { id: "p3", name: "Kanban Migration",        initial: "KM",  signals: ["action"], openCount: 1, last: "vor 8 h" },
    { id: "p4", name: "Lieferkette 2026",        initial: "L26", signals: ["calm"], openCount: 0, last: "vor 1 d" },
    { id: "p5", name: "Mobile Relaunch",         initial: "MR",  signals: ["review"], openCount: 3, last: "vor 3 d" },
    { id: "p6", name: "Onboarding Flow",         initial: "OF",  signals: ["calm"], openCount: 0, last: "vor 5 d" },
    { id: "p7", name: "Pricing Studie Q2",       initial: "PS",  signals: ["action"], openCount: 1, last: "vor 10 d" },
    { id: "p8", name: "Vertragswerk Neufassung", initial: "VW",  signals: ["conflict"], openCount: 2, last: "vor 3 w" },
  ],

  // Aktives Projekt für Detail-Screen
  active: {
    id: "p2",
    name: "Hafen Nord Erweiterung",
    customer: "Hafenbetrieb Nord AG",
    phase: "Designfreigabe",
    stakeholderCount: 6,
    budget: "210k EUR",

    // LAGE — Narrativer Lagetext, immer sichtbar
    lage: {
      kernsatz:
        "Designfreigabe steht. Zwei Konflikte blockieren die Migration. Timeline rutschte um zwei Wochen — drei Entscheidungen warten.",
      chips: [
        { label: "2 offene Konflikte", kind: "conflict" },
        { label: "3 Entscheidungen offen", kind: "review" },
        { label: "Review fällig", kind: "review" },
      ],
      naechsterTermin: { date: "18 Apr",  weekday: "Sa", topic: "Steering-Review" },
      letzteAenderung: { rel: "vor 2 h", what: "Neuer Go-Live-Termin erkannt" },
      outcome: "Self-Service 70% in 3 Mon · Reporting < 2 s",
    },

    // HANDLUNGSBEDARF — operatives Zentrum
    actions: [
      { id:"h1", mode:"entscheiden", kind:"konflikt", title:"Go-Live-Termin festlegen",
        sub:"15. Mai vs. 1. Juni — Steering muss entscheiden",
        owner:"Thomas Berger", due:"20 Apr", source:"Konflikt #k1", blocker:true },
      { id:"h2", mode:"entscheiden", kind:"konflikt", title:"Migrationsstrategie wählen",
        sub:"Big-Bang vs. Phasenweise — beide Optionen geprüft",
        owner:"Jan Krüger", due:"22 Apr", source:"Konflikt #k2", blocker:true },
      { id:"h3", mode:"klaeren", kind:"gap", title:"Performance-Anforderung definieren",
        sub:"Latenzziel & Concurrent-User-Zahl fehlen",
        owner:"Anna Weber", due:null, source:"Gap #g1", blocker:false },
      { id:"h4", mode:"klaeren", kind:"gap", title:"Migrations-Cutoff bestimmen",
        sub:"Stichtag für Altdatenstand festlegen",
        owner:null, due:"25 Apr", source:"Gap #g2", blocker:false },
      { id:"h5", mode:"klaeren", kind:"offener_punkt", title:"Mobile-First oder Desktop-First",
        sub:"UX-Richtung mit Fachseite abstimmen",
        owner:"Lisa Meier", due:null, source:"manuell ergänzt", blocker:false, manuell:true },
      { id:"h6", mode:"umsetzen", kind:"aufgabe", title:"Wireframes finalisieren",
        sub:"Letzte Iteration nach Steering-Feedback",
        owner:"Lisa Meier", due:"20 Apr", source:"UX Design", blocker:false },
      { id:"h7", mode:"umsetzen", kind:"aufgabe", title:"API-Dokumentation erstellen",
        sub:"OpenAPI-Spec für externe Partner",
        owner:"Jan Krüger", due:"25 Apr", source:"API-Integration", blocker:false },
      { id:"h8", mode:"pruefen",  kind:"feedback", title:"CTA-Stärke im UX-Prototyp prüfen",
        sub:"Feedback Dr. Weber: CTAs zu schwach",
        owner:"Lisa Meier", due:null, source:"Feedback Weber", blocker:false },
      { id:"h9", mode:"pruefen",  kind:"feedback", title:"PDF-Export für Reporting verifizieren",
        sub:"Anforderung aus Mail Berger 09.04",
        owner:null, due:null, source:"Mail · 09.04", blocker:false },
    ],

    // VERLAUF
    timeline: [
      { date:"15.04", delta:"neu",         text:"Neuer Go-Live-Termin: 15 Mai",        source:"Mail · Berger",       obj:"Termin" },
      { date:"14.04", delta:"bestaetigt",  text:"Budget 210k EUR bestätigt",            source:"manuell · du",        obj:"Entscheidung" },
      { date:"13.04", delta:"neu",         text:"Maria Schulz als Stakeholder",         source:"Org-Update.pptx",     obj:"Stakeholder" },
      { date:"12.04", delta:"widersprochen",text:"Migrationsstrategie-Konflikt erkannt",source:"Steering-Protokoll",  obj:"Konflikt" },
      { date:"12.04", delta:"neu",         text:"Steering-Protokoll v3 hochgeladen",    source:"Upload",              obj:"Dokument" },
      { date:"10.04", delta:"bestaetigt",  text:"React als Frontend bestätigt",         source:"Review #12",          obj:"Entscheidung" },
      { date:"08.04", delta:"ersetzt",     text:"UX-Prototyp v2 ersetzt v1",            source:"Lisa Meier",          obj:"Dokument" },
      { date:"05.04", delta:"neu",         text:"Konzeptphase abgeschlossen",           source:"Projektplan",         obj:"Milestone" },
    ],

    // SUBSTANZ
    themen: [
      { name:"UX Design",       e:2, p:1, d:4 },
      { name:"Datenmigration",  e:1, p:2, d:3 },
      { name:"API-Integration", e:1, p:1, d:2 },
      { name:"Reporting",       e:0, p:1, d:2 },
      { name:"Infrastruktur",   e:1, p:0, d:1 },
      { name:"Rechtliches",     e:0, p:0, d:1 },
    ],

    documents: [
      { name:"Steering Committee Protokoll", typ:"docx", v:3, date:"12.04", thema:"Go-Live" },
      { name:"UX-Prototyp Kundenportal",     typ:"pptx", v:2, date:"08.04", thema:"UX Design" },
      { name:"Migrationsstrategie Vergleich",typ:"pdf",  v:1, date:"10.04", thema:"Datenmigration" },
      { name:"API-Schnittstellenspec",        typ:"pdf",  v:1, date:"05.04", thema:"API-Integration" },
      { name:"Budget-Freigabe CFO",          typ:"eml",  v:1, date:"14.04", thema:"—" },
    ],
  },
};
